% A simple demo of the functionality of the gD function.

% Assume you want to generate spatial Gaussian kernels at a specific
% size -- the size of the patch you want to track (say MxN):
M = 64;
N = 64;

% Create a matrix of the correct size, with a single 'dot' in the
% center pixel:
kernel = zeros(M, N);
kernel(floor(M/2), floor(N/2)) = 1.0;

% To create the spatial Gaussian kernel we use the function 'gD',
% which is short for 'Gaussian derivative', but can be used to
% generate zero-order Gaussian derivatives too (i.e. Gaussians).
% The gD function convolves an image with a Gaussian derivative of
% the desired order (zero in this case):
kernel = gD(kernel, 3.0, 0, 0);
imagesc(kernel);
title('Spatial Gaussian kernel');

% Create the derivative of the spatial kernel in the x-direction (the
% pixels of this should be the first column of the Jacobian:
kernel_x = gD(kernel, 3.0, 1, 0);
figure; imagesc(kernel_x);
title('dK/dx');

% Create the derivative of the spatial kernel in the y-direction (the
% pixels of this should be the second column of the Jacobian:
kernel_y = gD(kernel, 3.0, 0, 1);
figure; imagesc(kernel_y);
title('dK/dy');


